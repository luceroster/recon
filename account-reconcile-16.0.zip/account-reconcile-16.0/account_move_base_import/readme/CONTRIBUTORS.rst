* Joël Grand-Guillaume <joel.grandguillaume@camptocamp.com>
* Nicolas Bessi <nicolas.bessi@camptocamp.com>
* Laurent Mignon <laurent.mignon@acsone.eu>
* Sébastien Beau <sebastien.beau@akretion.com>
* Matthieu Dietrich <matthieu.dietrich@camptocamp.com>
* Alexandre Fayolle <alexandre.fayolle@camptocamp.com>
* Akim Juillerat <akim.juillerat@camptocamp.com>
