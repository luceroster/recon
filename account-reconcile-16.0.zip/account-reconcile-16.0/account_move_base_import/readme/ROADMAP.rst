* As for now, the module does not handle multicurrency imports.
